# E-store

  	- First create databse in phpmyadmin with the same name of give SQL file name.
	- In that database import database.
	- Import given SQL file to the database.
